# wp-graphql-gutenberg-acf
Expose acf blocks through graphql


